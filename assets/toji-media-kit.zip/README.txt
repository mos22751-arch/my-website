TOJI Media Kit

Includes:
- social-preview.png
- profile.webp
- favicon.svg
- icon-192.png
- icon-512.png

Contact:
WhatsApp: +201102550730
Instagram: https://instagram.com/mouhamedmostafffa
TikTok: https://tiktok.com/@mouhamedmostafffa
Snapchat: https://www.snapchat.com/add/dr.toji
